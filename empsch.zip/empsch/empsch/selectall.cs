﻿namespace empsch
{
    internal class selectall
    {
    }
}