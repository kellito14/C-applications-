﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace empsch
{
    public partial class Form2 : Form

    {
        string connString = "Server=localhost;Database=employee;Uid=root;Pwd=;";
        public MySqlConnection conn;
        public Form2()
        {
            InitializeComponent();
        }
        private void checkall()
        {
            string Query;
            if (checkBox1.Checked && checkBox2.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Surname='" + lastnametxt.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox1.Checked && checkBox3.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Monday='" + mday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
               
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox1.Checked && checkBox4.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Tuesday='" + tday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox1.Checked && checkBox5.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Wednesday='" + wday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox1.Checked && checkBox6.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Thursday='" + thday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox1.Checked && checkBox7.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Friday='" + fday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox1.Checked && checkBox8.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox1.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
               
            }
            //checkbox2
            else if (checkBox2.Checked && checkBox3.Checked) 
                {
                Query = "update wbsch set Surname='" + lastnametxt.Text + "',Monday='" + mday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
               
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox2.Checked && checkBox4.Checked)
            {
                Query = "update wbsch set Surname='" + lastnametxt.Text + "',Tuesday='" + tday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
           
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox2.Checked && checkBox5.Checked)
            {
                Query = "update wbsch set Surname='" + lastnametxt.Text + "',Wednesday='" + wday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
            
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox2.Checked && checkBox6.Checked)
            {
                Query = "update wbsch set Surname='" + lastnametxt.Text + "',Thursday='" + thday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox2.Checked && checkBox7.Checked)
            {
                Query = "update wbsch set Surname='" + lastnametxt.Text + "',Friday='" + fday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox2.Checked && checkBox8.Checked)
            {
                Query = "update wbsch set Surname='" + lastnametxt.Text + "',Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox2.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set Surname='" + lastnametxt.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
             
                MyConn2.Close();//Connection closed here


              }

            else if (checkBox3.Checked && checkBox4.Checked)
            {
                Query = "update wbsch set Monday='" + mday.Text + "',Tuesday='" + tday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }

            else if (checkBox3.Checked && checkBox5.Checked)
            {
                Query = "update wbsch set Monday='" + mday.Text + "',Wednesday='" + wday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
             
                MyConn2.Close();//Connection closed here
            }

            else if (checkBox3.Checked && checkBox6.Checked)
            {
                Query = "update wbsch set Monday='" + mday.Text + "',Thursday='" + thday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }

            else if (checkBox3.Checked && checkBox7.Checked)
            {
                Query = "update wbsch set Monday='" + mday.Text + "',Friday='" + fday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }

            else if (checkBox3.Checked && checkBox8.Checked)
            {
                Query = "update wbsch set Monday='" + mday.Text + "',Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
               
                MyConn2.Close();//Connection closed here
            }

            else if (checkBox3.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set Monday='" + mday.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";

                
                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
           
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox4.Checked && checkBox5.Checked)
            {
                Query = "update wbsch set Tuesday='" + tday.Text + "',Wednesday='" + wday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
             
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox4.Checked && checkBox6.Checked)
            {
                Query = "update wbsch set Tuesday='" + tday.Text + "',Thursday='" + thday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox4.Checked && checkBox7.Checked)
            {
                Query = "update wbsch set Tuesday='" + tday.Text + "',Friday='" + fday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
            
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox4.Checked && checkBox8.Checked)
            {
                Query = "update wbsch set Tuesday='" + tday.Text + "',Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox4.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set Tuesday='" + tday.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
               
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox5.Checked && checkBox6.Checked)
            {
                Query = "update wbsch set Wednesday='" + wday.Text + "',Thursday='" + thday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
             
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox5.Checked && checkBox7.Checked)
            {
                Query = "update wbsch set Wednesday='" + wday.Text + "',Friday='" + fday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox5.Checked && checkBox8.Checked)
            {
                Query = "update wbsch set Wednesday='" + wday.Text + "',Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox5.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set Wednesday='" + wday.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox6.Checked && checkBox7.Checked)
            {
                Query = "update wbsch set Thursday='" + thday.Text + "',Friday='" + fday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
               
                MyConn2.Close();//Connection closed here
            }
             else if (checkBox6.Checked && checkBox8.Checked)
            {
                Query = "update wbsch set Thursday='" + thday.Text + "',Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
             
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox6.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set Thursday='" + thday.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox7.Checked && checkBox8.Checked)
            {
                Query = "update wbsch set Friday='" + fday.Text + "',Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
                
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox7.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set Friday='" + fday.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
            else if (checkBox8.Checked && checkBox9.Checked)
            {
                Query = "update wbsch set Saturday='" + sday.Text + "',Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";


                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
              
                MyConn2.Close();//Connection closed here
            }
        }



        //This ends the checkall class



            

        // update happens here.
        private void update_Click(object sender, EventArgs e)
        {
            checkall();

            //beg of update button
            string Query;
            //  string fname;// = firstnametxt.Text;
            string lname = lastnametxt.Text;
            //string id = upempId.Text;
            try
            {
                if (checkBox1.Checked)
                {
                    Query = "update wbsch set First_Name='" + firstnametxt.Text + "' where EmpId ='" + upempId.Text + "';";

                    //This is my update query in which i am taking input from the user through windows forms and update the record.
                    // string Query = "update wbsch set First_Name='" + this.textBox1.Text + "',Surname='" + this.textBox2.Text + "',Monday='" + this.mday.Text + "',Tuesday='" + this.tday.Text + "',Wednesday='" + this.wday.Text + "',Thursday ='" + this.thday.Text + "',Friday='" + this.fday.Text + "',Saturday='" + this.sday.Text + "',Sunday='" + this.sunday.Text +"' where EmpId='" + this.upempId.Text + "';";
                    //This is  MySqlConnection here i have created the object and pass my connection string.


                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                  
                    MyConn2.Close();//Connection closed here

                }
                else if (checkBox2.Checked)
                {
                    Query = "update wbsch set Surname ='" + lastnametxt.Text + "' where EmpId ='" + upempId.Text + "';";

                    //This is my update query in which i am taking input from the user through windows forms and update the record.
                    // string Query = "update wbsch set First_Name='" + this.textBox1.Text + "',Surname='" + this.textBox2.Text + "',Monday='" + this.mday.Text + "',Tuesday='" + this.tday.Text + "',Wednesday='" + this.wday.Text + "',Thursday ='" + this.thday.Text + "',Friday='" + this.fday.Text + "',Saturday='" + this.sday.Text + "',Sunday='" + this.sunday.Text +"' where EmpId='" + this.upempId.Text + "';";
                    //This is  MySqlConnection here i have created the object and pass my connection string.


                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                 
                    MyConn2.Close();//Connection closed here
                }
                else if (checkBox3.Checked)
                {

                    Query = "update wbsch set Monday='" + mday.Text + "' where EmpId ='" + upempId.Text + "';";

                    //This is my update query in which i am taking input from the user through windows forms and update the record.
                    // string Query = "update wbsch set First_Name='" + this.textBox1.Text + "',Surname='" + this.textBox2.Text + "',Monday='" + this.mday.Text + "',Tuesday='" + this.tday.Text + "',Wednesday='" + this.wday.Text + "',Thursday ='" + this.thday.Text + "',Friday='" + this.fday.Text + "',Saturday='" + this.sday.Text + "',Sunday='" + this.sunday.Text +"' where EmpId='" + this.upempId.Text + "';";
                    //This is  MySqlConnection here i have created the object and pass my connection string.


                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                  
                    MyConn2.Close();//Connection closed here

                }
                else if (checkBox4.Checked)
                {
                    Query = "update wbsch set Tuesday='" + tday.Text + "' where EmpId ='" + upempId.Text + "';";

                    //This is my update query in which i am taking input from the user through windows forms and update the record.
                    // string Query = "update wbsch set First_Name='" + this.textBox1.Text + "',Surname='" + this.textBox2.Text + "',Monday='" + this.mday.Text + "',Tuesday='" + this.tday.Text + "',Wednesday='" + this.wday.Text + "',Thursday ='" + this.thday.Text + "',Friday='" + this.fday.Text + "',Saturday='" + this.sday.Text + "',Sunday='" + this.sunday.Text +"' where EmpId='" + this.upempId.Text + "';";
                    //This is  MySqlConnection here i have created the object and pass my connection string.


                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                   
                    MyConn2.Close();//Connection closed here

                }
                else if (checkBox5.Checked)
                {
                    Query = "update wbsch set Wednesday='" + wday.Text + "' where EmpId ='" + upempId.Text + "';";

                  

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                   
                    MyConn2.Close();//Connection closed here
                }
                else if (checkBox6.Checked)
                {
                    Query = "update wbsch set Thursday='" + thday.Text + "' where EmpId ='" + upempId.Text + "';";



                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                   
                    MyConn2.Close();//Connection closed here
                }
                else if (checkBox7.Checked)
                {
                    Query = "update wbsch set Friday='" + fday.Text + "' where EmpId ='" + upempId.Text + "';";



                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                   
                    MyConn2.Close();//Connection closed here
                }
                else if (checkBox8.Checked)
                {
                    Query = "update wbsch set Saturday='" + sday.Text + "' where EmpId ='" + upempId.Text + "';";



                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                 
                    MyConn2.Close();//Connection closed here
                }
                else if (checkBox9.Checked)
                {
                    Query = "update wbsch set Sunday='" + sunday.Text + "' where EmpId ='" + upempId.Text + "';";



                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                  
                    MyConn2.Close();//Connection closed here
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            string Query;
            checkBox1.Checked = true;
            checkBox2.Checked = true;
            checkBox3.Checked = true;
            checkBox4.Checked = true;
            checkBox5.Checked = true;
            checkBox6.Checked = true;
            checkBox7.Checked = true;
            checkBox8.Checked = true;
            checkBox9.Checked = true;

            if (checkBox1.Checked && checkBox2.Checked && checkBox3.Checked && checkBox4.Checked && checkBox5.Checked && checkBox6.Checked && checkBox7.Checked && checkBox8.Checked && checkBox9.Checked)
            {

                //This is my update query in which i am taking input from the user through windows forms and update the record.
                Query = "update wbsch set First_Name='" + firstnametxt.Text + "',Surname='" + lastnametxt.Text + "',Monday='" + mday.Text + "',Tuesday='" + tday.Text + "',Wednesday='" + wday.Text + "',Thursday ='" + thday.Text + "',Friday='" + fday.Text + "',Saturday='" + sday.Text + "',Sunday='" + sunday.Text + "' where EmpId='" + upempId.Text + "';";
                //This is  MySqlConnection here i have created the object and pass my connection string.

                try
                {
                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                    while (MyReader2.Read())
                    {
                    }
                    MyConn2.Close();//Connection closed here
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (checkBox10.Checked == false)

            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox8.Checked = false;
                checkBox9.Checked = false;

            }

        }
    }
}
