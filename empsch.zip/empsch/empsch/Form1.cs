﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace empsch { 

   
    public partial class Form1 : Form
    {
        //string connString = "localhost; Database=employee;Uid=root;Pwd=apple;";
        string connString = "Server=52.37.24.161;port=80; Database=employee;Uid=kellito;Pwd=apple;";
        public MySqlConnection conn;
        
        public Form1() 
          
        {
            InitializeComponent();
            
        }

        //post username and password to database
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //   string MyConnection2 = "datasource=localhost;username=root;password=";

                //Display query
             //   string Query = "select * from wbsch;";
               string Query = "select EmpId,First_Name, Surname, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday from wbsch;";
                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                  MyConn2.Open();
                //For offline connection we weill use  MySqlDataAdapter class.
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = MyCommand2;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.             
                                                   MyConn2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           


        }
        /*button2 allows the user to delete entries*/
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string Query = "delete from wbsch where EmpId='" + this.textBox3.Text + "';";
                MySqlConnection MyConn2 = new MySqlConnection(connString);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Deleted");
                MyConn2.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //RadioButton1 displays the fields for Delete option
        private void radioButton1_Click(object sender, EventArgs e)
        {
            textBox3.Visible = true;
            button2.Visible = true;
            label4.Visible = true;

            //hides radio button 2
            textBox1.Visible = false;
            textBox2.Visible = false;

            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            textBox2.Visible = false;
            button3.Visible = false;
            NewId.Visible = false;
            //hides radio button 3
            Form2 frm = new Form2();
            frm.Close();


        }
        /*These two voids don't do nothing but can't delete them*/
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        /*Appears once the user selects the radio button2 option*/
        private void add_Employee(object sender, EventArgs e)
        {
            try
            {
                
                string Query = "insert into wbsch(EmpId,First_Name,Surname) values('" + this.NewId.Text + "','" + this.textBox1.Text + "','" + this.textBox2.Text+ "');";
                //This is  MySqlConnection here i have created the object and pass my connection string.
                MySqlConnection MyConn2 = new MySqlConnection(connString);
                //This is command class which will handle the query and connection object.
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();     // Here our query will be executed and data saved into the database.
                MessageBox.Show("Save Data");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /*New Employee radio button. Display the entry form to add a new employee to the schedule*/
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Visible = true;
           
            textBox2.Visible = true;
            button3.Visible = true;
            NewId.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;

            //Hides radio button 1
            textBox3.Visible = false;
            button2.Visible = false;
            label4.Visible = false;
            //hides radio button 3
 

            
            Form2 frm = new Form2();
            frm.Close();
        }

       /*Displays the form for updating employee schedule*/

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

           
            Form2 frm = new Form2();
            frm.Show();

            if (radioButton1.Checked == true || radioButton2.Checked == true)
            {
                frm.Close();


            }
            else {
                frm.Show();
            }

        }








    }
}
 