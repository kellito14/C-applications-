﻿namespace empsch
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.upempId = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.firstnametxt = new System.Windows.Forms.TextBox();
            this.lastnametxt = new System.Windows.Forms.TextBox();
            this.mday = new System.Windows.Forms.TextBox();
            this.tday = new System.Windows.Forms.TextBox();
            this.wday = new System.Windows.Forms.TextBox();
            this.thday = new System.Windows.Forms.TextBox();
            this.fday = new System.Windows.Forms.TextBox();
            this.sday = new System.Windows.Forms.TextBox();
            this.sunday = new System.Windows.Forms.TextBox();
            this.update = new System.Windows.Forms.Button();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(12, 114);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 17);
            this.checkBox1.TabIndex = 23;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(12, 185);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(80, 17);
            this.checkBox2.TabIndex = 24;
            this.checkBox2.Text = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // upempId
            // 
            this.upempId.Location = new System.Drawing.Point(108, 24);
            this.upempId.Name = "upempId";
            this.upempId.Size = new System.Drawing.Size(100, 20);
            this.upempId.TabIndex = 25;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(258, 120);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(64, 17);
            this.checkBox3.TabIndex = 26;
            this.checkBox3.Text = "Monday";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(258, 143);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(67, 17);
            this.checkBox4.TabIndex = 27;
            this.checkBox4.Text = "Tuesday";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(257, 169);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(83, 17);
            this.checkBox5.TabIndex = 28;
            this.checkBox5.Text = "Wednesday";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(258, 194);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(70, 17);
            this.checkBox6.TabIndex = 29;
            this.checkBox6.Text = "Thursday";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // firstnametxt
            // 
            this.firstnametxt.Location = new System.Drawing.Point(12, 137);
            this.firstnametxt.Name = "firstnametxt";
            this.firstnametxt.Size = new System.Drawing.Size(100, 20);
            this.firstnametxt.TabIndex = 30;
            // 
            // lastnametxt
            // 
            this.lastnametxt.Location = new System.Drawing.Point(12, 217);
            this.lastnametxt.Name = "lastnametxt";
            this.lastnametxt.Size = new System.Drawing.Size(100, 20);
            this.lastnametxt.TabIndex = 31;
            // 
            // mday
            // 
            this.mday.Location = new System.Drawing.Point(344, 114);
            this.mday.Name = "mday";
            this.mday.Size = new System.Drawing.Size(100, 20);
            this.mday.TabIndex = 32;
            // 
            // tday
            // 
            this.tday.Location = new System.Drawing.Point(344, 140);
            this.tday.Name = "tday";
            this.tday.Size = new System.Drawing.Size(100, 20);
            this.tday.TabIndex = 33;
            // 
            // wday
            // 
            this.wday.Location = new System.Drawing.Point(344, 166);
            this.wday.Name = "wday";
            this.wday.Size = new System.Drawing.Size(100, 20);
            this.wday.TabIndex = 34;
            // 
            // thday
            // 
            this.thday.Location = new System.Drawing.Point(344, 192);
            this.thday.Name = "thday";
            this.thday.Size = new System.Drawing.Size(100, 20);
            this.thday.TabIndex = 35;
            // 
            // fday
            // 
            this.fday.Location = new System.Drawing.Point(344, 217);
            this.fday.Name = "fday";
            this.fday.Size = new System.Drawing.Size(100, 20);
            this.fday.TabIndex = 36;
            // 
            // sday
            // 
            this.sday.Location = new System.Drawing.Point(344, 243);
            this.sday.Name = "sday";
            this.sday.Size = new System.Drawing.Size(100, 20);
            this.sday.TabIndex = 37;
            // 
            // sunday
            // 
            this.sunday.Location = new System.Drawing.Point(344, 269);
            this.sunday.Name = "sunday";
            this.sunday.Size = new System.Drawing.Size(100, 20);
            this.sunday.TabIndex = 38;
            // 
            // update
            // 
            this.update.Location = new System.Drawing.Point(214, 24);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(75, 23);
            this.update.TabIndex = 39;
            this.update.Text = "Update";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(257, 217);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(54, 17);
            this.checkBox7.TabIndex = 40;
            this.checkBox7.Text = "Friday";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(257, 243);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(68, 17);
            this.checkBox8.TabIndex = 41;
            this.checkBox8.Text = "Saturday";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(258, 269);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(62, 17);
            this.checkBox9.TabIndex = 42;
            this.checkBox9.Text = "Sunday";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(257, 304);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(70, 17);
            this.checkBox10.TabIndex = 43;
            this.checkBox10.Text = "Select All";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(985, 571);
            this.Controls.Add(this.checkBox10);
            this.Controls.Add(this.checkBox9);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.update);
            this.Controls.Add(this.sunday);
            this.Controls.Add(this.sday);
            this.Controls.Add(this.fday);
            this.Controls.Add(this.thday);
            this.Controls.Add(this.wday);
            this.Controls.Add(this.tday);
            this.Controls.Add(this.mday);
            this.Controls.Add(this.lastnametxt);
            this.Controls.Add(this.firstnametxt);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.upempId);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Name = "Form2";
            this.Text = "Employee Update Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.TextBox upempId;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.TextBox firstnametxt;
        private System.Windows.Forms.TextBox lastnametxt;
        private System.Windows.Forms.TextBox mday;
        private System.Windows.Forms.TextBox tday;
        private System.Windows.Forms.TextBox wday;
        private System.Windows.Forms.TextBox thday;
        private System.Windows.Forms.TextBox fday;
        private System.Windows.Forms.TextBox sday;
        private System.Windows.Forms.TextBox sunday;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
    }
}