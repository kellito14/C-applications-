﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace taskschedulecsharp
{
    public partial class Form1 : Form
    {
        string connString = "Server=localhost;Database=tasksch;Uid=root;Pwd=;";
        public MySqlConnection conn;
        string Query;
       
        public Form1()
        {
            InitializeComponent();
    
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /*This adds the date, month, and task(s) to the schedule*/

        private void button1_Click(object sender, EventArgs e)//add new entry
        {



            try
            {

                Query = "insert into tsksch(Month,Day,Year,Task) values('" + entry.Text + "','" + entrytwo.Text + "','" + entrythree.Text + "', '" + entryfour.Text + "');";
                //This is  MySqlConnection here i have created the object and pass my connection string.
                MySqlConnection MyConn2 = new MySqlConnection(connString);
                //This is command class which will handle the query and connection object.
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();     // Here our query will be executed and data saved into the database.
                MessageBox.Show("Save Data");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /*The user clicks on the calendar to display all tasks for that month*/
        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        
            

            
            try
            {

               
                    
                        Query = "Select num,Month,Day,Year,Task from tsksch;";

                        MySqlConnection MyConn2 = new MySqlConnection(connString);
                        MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                        MyConn2.Open();
                        //For offline connection we weill use  MySqlDataAdapter class.
                        MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                        MyAdapter.SelectCommand = MyCommand2;
                        DataTable dTable = new DataTable();
                        MyAdapter.Fill(dTable);


                        dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                        dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                        MyConn2.Close();


                 
                
            

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        /*Updates the entry*/
        private void button2_Click(object sender, EventArgs e)
        {

          
            try
            {


                {
                    Query = "update tsksch set Month='"+upentry.Text + "',Day='"+upentrytwo.Text+"',Year='"+upentrythree.Text+"',Task='"+upentryfour.Text+"' where num ='"+upentryfive.Text+"';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.             
                    MyConn2.Close();
                    MessageBox.Show("Successfully Updated!");


                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        //Filters out other rows not associated with current selection. 
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = comboBox1.SelectedIndex;
            Object selectedItem = comboBox1.SelectedItem;

            try {
                if (selectedItem.Equals("January"))
                {

                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'January';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
              //      MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();

                }
                else if(selectedItem.Equals("February")) {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'February';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                   // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("March"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'March';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("April"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'April';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("May"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'May';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("June"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'June';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("July"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'July';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("August"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'August';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("September"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'September';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("October"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'October';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("November"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'November';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
                else if (selectedItem.Equals("December"))
                {
                    Query = "Select num,Month,Day,Year,Task from tsksch where Month = 'February';";

                    MySqlConnection MyConn2 = new MySqlConnection(connString);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MyConn2.Open();
                    //For offline connection we weill use  MySqlDataAdapter class.
                    MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                    MyAdapter.SelectCommand = MyCommand2;
                    DataTable dTable = new DataTable();
                    MyAdapter.Fill(dTable);
                    // MessageBox.Show(dTable.ToString());

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.           

                    MyConn2.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
